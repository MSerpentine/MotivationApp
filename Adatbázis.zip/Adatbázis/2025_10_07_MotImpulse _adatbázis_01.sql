CREATE TABLE `users` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `email` varchar(100) UNIQUE NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT (current_timestamp),
  `updated_at` datetime DEFAULT (current_timestamp)
);

CREATE TABLE `quotes` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `min_score` int NOT NULL,
  `max_score` int NOT NULL,
  `quote_text` text NOT NULL,
  `author` varchar(100),
  `created_at` datetime DEFAULT (current_timestamp)
);

CREATE TABLE `entries` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `quote_id` int,
  `entry_date` date NOT NULL,
  `mood` int,
  `sleep_hours` decimal(3,1),
  `activities` text,
  `weather` varchar(50),
  `health_status` varchar(100),
  `notes` text,
  `daily_score` int,
  `is_deleted` boolean DEFAULT false,
  `created_at` datetime DEFAULT (current_timestamp),
  `updated_at` datetime DEFAULT (current_timestamp)
);

CREATE TABLE `sessions` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `session_token` varchar(255) UNIQUE NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT (current_timestamp)
);

ALTER TABLE `entries` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `entries` ADD FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`);

ALTER TABLE `sessions` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
